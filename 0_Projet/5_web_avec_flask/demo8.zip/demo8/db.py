import sqlite3 as db

def init_db():
    conn = db.connect("mini_blog.db")  # connect(nom_fichier) renvoie un handler de connexion
    with open("schema.sql") as script:  # Ouverture du fichier contenant le schéma de la base
        conn.executescript(script.read())  # Sa lecture donne une chaîne qu'on passe à executescript(sql)
    conn.close()


def recuperer_articles():
    """Renvoie une liste de tuples
    de la forme (id_article, login, cree_le, titre, contenu)"""

    with db.connect("mini_blog.db") as c:
        curs = c.execute(
            """SELECT articles.id, login, cree_le, titre, contenu 
               FROM membres JOIN articles
                 ON membres.id = articles.auteur_id
                 ORDER BY articles.cree_le DESC
            """
        )
        return curs.fetchall()


def inserer_article(auteur_id, titre, contenu):
    with db.connect("mini_blog.db") as c:
        curs = c.execute(
            """INSERT INTO articles (auteur_id, titre, contenu) 
              VALUES (?, ?, ?)""",
            (auteur_id, titre, contenu)
        )
        c.commit()


def supprimer_article(id_article):
    with db.connect("mini_blog.db") as c:
        curs = c.execute(
            """DELETE FROM articles WHERE id = ?""",
            (id_article,)
        )
        c.commit()


def recuperer_membre(login):
    """Renvoie un tuple de la forme (id_membre, mot de passe)
    ou None si aucun membre n'a le login indiqué."""

    with db.connect("mini_blog.db") as c:
        curs = c.execute(
            """SELECT id, mdp FROM membres WHERE login = ?""",
            (login,)
        )
        return curs.fetchone()


init_db()