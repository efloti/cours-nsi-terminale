from flask import Flask, render_template, request, session, redirect, url_for, g
from db import *

app = Flask(__name__)
app.secret_key = "dev"

@app.route('/')
def accueil():
    return render_template(
        'accueil.html', # template situé dans le répertoire templates/app7
        articles=recuperer_articles()
    )

@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method == "POST":
        login = request.form["login"]
        mdp = request.form["mdp"]
        membre = recuperer_membre(login)
        # membre = None ou est de la forme (id, mdp)
        if membre and membre[1] == mdp: # mieux: check_password_hash(membre[1], mdp)
            session.clear()
            # enregistrons quelques informations utiles dans l'objet session.
            session['mbrid'] = membre[0]
            session['login'] = login
            return redirect(url_for('accueil'))
    # si "GET" ou si l'utilisateur n'est pas reconnue
    return render_template(
        'login.html'
    )

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('accueil'))

@app.route('/supprimer/<int:id>')
def supprimer(id):
    supprimer_article(id)
    return redirect(url_for('accueil'))

# la suite sert juste de «bouche trou»
@app.route('/inscription')
def inscription():
    return redirect(url_for('accueil'))

@app.route('/editer')
def editer():
    return redirect(url_for('accueil'))